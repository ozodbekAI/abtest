"""Add atomic store/card locking, stage metrics, audit events and funding provenance.

Revision ID: 0015_ab_test_safety_invariants
Revises: 0014_wb_connection_token_fingerprint
"""
from alembic import op
import sqlalchemy as sa

revision = "0015_ab_test_safety_invariants"
down_revision = "0014_wb_connection_token_fingerprint"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("ab_tests", sa.Column("store_fingerprint", sa.String(length=64), nullable=False, server_default=""))
    op.add_column("ab_tests", sa.Column("lifecycle_lock", sa.Boolean(), nullable=False, server_default=sa.true()))
    op.add_column("ab_tests", sa.Column("stage_views", sa.Integer(), nullable=False, server_default="0"))
    op.add_column("ab_tests", sa.Column("stage_clicks", sa.Integer(), nullable=False, server_default="0"))
    op.add_column("ab_tests", sa.Column("stage_spend_rub", sa.Float(), nullable=False, server_default="0"))
    op.add_column("ab_tests", sa.Column("funding_source", sa.String(length=16), nullable=False, server_default="auto"))
    op.create_index("ix_ab_tests_store_fingerprint", "ab_tests", ["store_fingerprint"])
    op.create_index("ix_ab_tests_lifecycle_lock", "ab_tests", ["lifecycle_lock"])
    op.create_index("uq_ab_test_store_card_open", "ab_tests", ["store_fingerprint", "nm_id"], unique=True, postgresql_where=sa.text("lifecycle_lock = true"))
    op.create_table(
        "ab_test_audit_events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("test_id", sa.Integer(), sa.ForeignKey("ab_tests.id", ondelete="CASCADE"), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("action", sa.String(length=64), nullable=False),
        sa.Column("before_state", sa.JSON(), nullable=False, server_default="{}"),
        sa.Column("after_state", sa.JSON(), nullable=False, server_default="{}"),
        sa.Column("details", sa.JSON(), nullable=False, server_default="{}"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_ab_test_audit_events_test_id", "ab_test_audit_events", ["test_id"])
    op.create_index("ix_ab_test_audit_events_user_id", "ab_test_audit_events", ["user_id"])
    op.create_index("ix_ab_test_audit_events_action", "ab_test_audit_events", ["action"])


def downgrade():
    op.drop_index("ix_ab_test_audit_events_action", table_name="ab_test_audit_events")
    op.drop_index("ix_ab_test_audit_events_user_id", table_name="ab_test_audit_events")
    op.drop_index("ix_ab_test_audit_events_test_id", table_name="ab_test_audit_events")
    op.drop_table("ab_test_audit_events")
    op.drop_index("uq_ab_test_store_card_open", table_name="ab_tests")
    op.drop_index("ix_ab_tests_lifecycle_lock", table_name="ab_tests")
    op.drop_index("ix_ab_tests_store_fingerprint", table_name="ab_tests")
    for name in ("funding_source", "stage_spend_rub", "stage_clicks", "stage_views", "lifecycle_lock", "store_fingerprint"):
        op.drop_column("ab_tests", name)
