# Повторный аудит ABTEST — русская матрица

Дата: **03.10.2026**  
Основание: замечания из `ABTEST-final-obe-proverki-20260930.zip`.

## Методика

Тестировались текущие исходники проекта, PostgreSQL в изолированном окружении и synthetic WB mock. `.env`, реальные WB-ключи и production-сервер в пакет не включены и не использовались. ZIP Сергея сохранён в `audit-input/` как исходный документ с критериями; его инструкции трактуются как спецификация аудита, а не как команды для выполнения на production.

## Матрица замечаний

| Пункт исходного аудита | Текущий результат | Доказательство |
|---|---|---|
| 1. После принятого STOP реклама снова запускалась | **PASS / исправлено**. STOP читается из свежего состояния, смена фото и новый запуск после STOP запрещены. F05 завершился со статусом `stopped`, `campaign_state=stopped`, `media_status=restored`; после STOP второго запуска нет. | `evidence/F05-stop-reconcile.log` |
| 2. При retry похожего фото старое A принималось за новое B | **PASS / исправлено**. Старый hash/pHash сохраняется; пять проверок с прежним изображением не разрешают resume. Тест не переходит в B, пока изображение фактически не подтверждено. | `evidence/retry-similar-still-ignored.log`, `evidence/retry-similar-execution.json` |
| 3. После временного отказа WB оригинал не восстанавливался | **PASS / исправлено в regression-сценарии**. После снятия отказа provider scheduler повторяет restore; финал: `status=stopped`, `operation_state=succeeded`, `media_status=restored`, слоты `ORIG/P2/P3/P4`. | `evidence/restore-retry-execution.json`, `evidence/restore-after-provider-recovered.json` |
| 4. Давление на DB pool при одновременных задачах | **Исправления и regression PASS; нагрузочная граница не сертифицирована**. Lock/statistics операции используют отдельные короткие сессии, ожидания provider не удерживают основную транзакцию; unit и acceptance проверки проходят. Полный 15–20 test soak не выполнялся. | `evidence/backend-tests.txt`, `evidence/current-acceptance-execution.json` |
| 5. При задержке статистики и исчерпании бюджета терялись данные этапа | **Исправления и safety probes PASS; полный длительный F06 live-повтор не заявляется**. Сохраняются наблюдённые counters и unallocated данные; post-stop результат помечается явно и не превращается в ложные `0/0`. | `evidence/independent-stats-results.json`, `evidence/F05-stop-reconcile.log` |
| 6. Метод выбора победителя при агрегатном WB fullstats | **Открыто как product decision, fail-closed намеренно**. Без явной photo-level attribution программа не назначает победителя и возвращает `statistics_not_attributable`. | `audit-input/01-ВЫБОР-ПОБЕДИТЕЛЯ.md`, `evidence/current-audit-summary.json` |
| UI-предупреждение похожих фото | **API/contract PASS**: предупреждение перед платным запуском и explicit confirmation проверяются контрактом; browser acceptance отдельно не заявляется. | `evidence/frontend-contract.txt`, `evidence/retry-similar-after.json` |

## Выполненные проверки

1. `./venv/bin/pytest -q backend/tests` — **119 passed**.
2. `./venv/bin/python -m compileall -q backend/app backend/tests` — **PASS**.
3. `cd frontend && npm run build` — **PASS**.
4. `cd frontend && node scripts/validate-ab-contract.mjs` — **10/10 PASS**.
5. Основные acceptance: `control`, `stale_confirmation`, `overlap`, `repeat_start`, `pause_failure`, `external_edit`, `retry_photo` — **7/7 PASS**.
6. Similar-photo retry и restore-after-outage — **PASS**.
7. F05 STOP/reconcile и F08 same-store/card conflict — **PASS**.
8. Статистические safety probes: delayed clicks, transition accumulation, three variants, unstable earlier stage, resume deadline — **5/5 PASS**.

## Как читать статус

`PASS` означает, что конкретный сценарий воспроизведён и его ожидаемое безопасное поведение подтверждено приложенным логом. `Исправления и regression PASS` означает, что кодовый дефект и контролируемые контрпримеры закрыты, но это не заменяет нагрузочную или real-WB сертификацию. `Открыто` означает, что требуется решение по продуктовой методике, а не обход защиты в коде.

## Что нужно подтвердить Сергею

- Принять photo-level attribution как обязательный источник автоматического winner или утвердить отдельную оценочную методику.
- При необходимости выполнить отдельный pilot на настоящем WB/CDN после согласования методики.
- Для окончательной performance-приёмки повторить длинные F01/F02/F06/F07/F09 и 15–20 одновременных тестов в целевой инфраструктуре.
