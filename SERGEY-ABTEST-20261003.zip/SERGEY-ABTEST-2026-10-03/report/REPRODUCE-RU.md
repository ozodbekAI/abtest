# Как повторить проверки

## Локальные автоматические проверки

Из корня проекта:

```bash
./venv/bin/pytest -q backend/tests
./venv/bin/python -m compileall -q backend/app backend/tests
(cd frontend && npm run build)
(cd frontend && node scripts/validate-ab-contract.mjs)
```

## Acceptance и synthetic WB

Сценарии и harness находятся в `source/sergey-e2e/` и в исходном audit ZIP в `audit-input/`. Для повторения нужен PostgreSQL 16 и Python virtualenv проекта. Не подключайте `.env` с реальными ключами к synthetic harness.

Доказательства уже выполненного прогона находятся в `evidence/`. В частности:

- `current-acceptance-execution.json` — семь основных acceptance-сценариев;
- `retry-similar-execution.json` — retry похожего фото;
- `restore-retry-execution.json` — restore после provider outage;
- `F05-stop-reconcile.log` — STOP во время сверки;
- `F08-conflict.log` — изоляция магазина/карточки;
- `independent-stats-results.json` — пять арифметических safety probes.

## Ограничения

Не запускайте реальные mutation endpoints WB и production deployment как часть этого локального отчёта. Реальную WB-приёмку выполняйте отдельно после подтверждения Сергеем winner methodology и с отдельным бюджетом/карточками.
